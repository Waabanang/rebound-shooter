General Purpose 2D Collision Detection System

Documentation and examples here:
http://vrld.github.com/HardonCollider
